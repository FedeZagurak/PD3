-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 20-11-2021 a las 00:34:26
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ProdD3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `artistas`
--

CREATE TABLE `artistas` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `bio` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `artistas`
--

INSERT INTO `artistas` (`id`, `nombre`, `apellido`, `bio`, `foto`) VALUES
(1, '<h1>Victor', 'Vasarely</h1>', '<p>Hungría, 1906-1997. Fue uno de los más destacados artistas del arte óptico y del cinetismo. Implementó la contraposición de dos sistemas de perspectiva y de zonas de color con igual valor tonal.\r\n</p> \r\n<p>Uno de los recursos más utilizados fue la ambiguedad óptica. Tuvo una obra pública\r\ndestacada desde sus primeras intervenciones en la\r\nCiudad Universitaria de Caracas.\r\n</p>', '../../img/art1.jpeg'),
(3, '<h1>Jean', 'Tinguely</h1>', '<p>Friburgo, Suiza, 22 de mayo de 1925–Berna, 30 de agosto de 1991.\r\nFue un pintor y escultor suizo. A través de su arte Tinguely satirizó la\r\nsobreproducción sin sentido de bienes materiales por parte de la\r\nsociedad industrial avanzada.\r\nJean Tinguely por Erling Mandelmann, 1963.\r\n</p>\r\n<p>Tinguely creció en Basilea, pero se mudó a Francia en su juventud\r\npara desarrollar su carrera artística. Perteneció al movimiento de\r\navantgarde (vanguardia) parisino de mediados del siglo XX y fue uno\r\nde los artistas que firmó el manifiesto Neorrealista (Nouveau réalisme) en 1960.\r\n</p>\r\n<p>Su obra más famosa es una escultura que se autodestruye, llamada\r\nHomenaje a Nueva York (1960), se autodestruyó en forma parcial en\r\nel Museum of Modern Art, de Nueva York, aunque su obra posterior,\r\nEstudio No.2 para un fin del mundo (1962), detonó de forma exitosa\r\nenfrente del público reunido en el desierto cerca de Las Vegas.\r\nEn 1971, Tinguely se casó con la artista francesa Niki de Saint Phalle.\r\n</p>', '../../img/art4.jpeg'),
(4, '<h1>Jesus Rafael', 'Soto</h1>', '<p>Venezuela, 1923-2005. Inspirado en el sistema musical dodecafónico y la música serial, usó la repetición y las progresiones para lograr un efecto de continuidad y evolución de la repetición serial. \r\n</p>\r\n<p>Concebía el espacio como parte de la materia de su obra y entendía que el ser humano no estaba frente al espacio sino que era parte de este. Destacó por la creación de los penetrables.\r\n</p>', '../../img/art2.jpeg'),
(5, '<h1>Carlos', 'Cruz-Diez</h1>', '<p>\r\nVenezuela, 1923-2019. Hizo de la vibración colorista el centro de su propuesta. Conocido por usar listones estrechos de color, dispuestos en ángulo recto con respecto a la superficie de la obra. Así, el color refracta sobre la superficie y, en la medida en que se desplaza el espectador, la obra modifica creando la sensación de movimiento.\r\n</p>', '../../img/art3.jpeg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `email`, `usuario`, `password`) VALUES
(1, 'Federico', 'Zagurak', 'fedezagurak13@gmail.com', 'fzagur', '202cb962ac59075b964b07152d234b70'),
(3, 'Tini', 'Tini', 'tini@tini.com', 'Tini', 'c206e2b98c4df6842423d92438c93b92'),
(32, 'Fede', 'Zagurak', 'fede@gmail.com', 'fede', '202cb962ac59075b964b07152d234b70');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `artistas`
--
ALTER TABLE `artistas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `artistas`
--
ALTER TABLE `artistas`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
